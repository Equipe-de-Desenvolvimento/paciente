<p style="text-align: center;"><u><b> <?=$laudo['0']->cabecalho; ?></u></b></p>
   
<p><?= $laudo['0']->texto; ?></p>


                <?
        if ($laudo['0']->rodape == "t") {
            ?>
            <FONT size="-1"> REALIZAMOS EXAMES DE RESSON&Acirc;NCIA MAGN&Eacute;TICA DE ALTO CAMPO (1,5T)
            <?
        }
        ?>

